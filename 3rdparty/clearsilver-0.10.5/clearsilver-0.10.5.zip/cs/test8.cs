
some tests for new var is an expression

<?cs var:"5" ?>

<?cs var:"5" + #1 ?>

<?cs var:"big" + " is better" ?>

<?cs var:Blah + " potato " + Foo.Bar.Baz.0 ?>
