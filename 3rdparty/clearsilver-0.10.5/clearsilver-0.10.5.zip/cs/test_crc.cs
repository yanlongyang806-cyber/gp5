<?cs var:string.crc("my string") ?>
<?cs var:string.crc("my other string") ?>
<?cs var:string.crc("my first string") ?>
