

<?cs var:name(Wow.Foo) ?>

<?cs each:count = Foo.Bar.Baz ?>
  <?cs var:name(count) ?>
<?cs /each ?>
