<html>
<body>

<p>
This is an html file language string which should be translated..</p>

</body>
</html>
