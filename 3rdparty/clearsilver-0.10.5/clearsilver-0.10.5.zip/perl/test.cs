<?cs if:TopNode.2nd1.Entry1 ?>
<?cs var:TopNode.2nd1.Entry1 ?>
<?cs /if ?>
<?cs each:leaf =TopNode.2nd1 ?>
<?cs var:leaf ?>
<?cs /each ?>

