GLOBAL(void) jinit_c_codec (j_compress_ptr cinfo);
GLOBAL(void) jinit_d_codec (j_decompress_ptr cinfo);